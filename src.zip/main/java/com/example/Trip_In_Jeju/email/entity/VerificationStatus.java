package com.example.Trip_In_Jeju.email.entity;

public  enum VerificationStatus {
    PENDING,
    COMPLETE
}