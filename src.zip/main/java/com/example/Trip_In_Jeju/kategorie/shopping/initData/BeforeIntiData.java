package com.example.Trip_In_Jeju.kategorie.shopping.initData;

public interface BeforeIntiData {
    default void beforeInit() {

    }
}
