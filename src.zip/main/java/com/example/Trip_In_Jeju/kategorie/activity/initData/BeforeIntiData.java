package com.example.Trip_In_Jeju.kategorie.activity.initData;

public interface BeforeIntiData {
    default void beforeInit() {

    }
}
