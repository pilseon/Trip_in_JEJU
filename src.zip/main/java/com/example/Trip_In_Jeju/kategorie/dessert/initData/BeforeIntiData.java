package com.example.Trip_In_Jeju.kategorie.dessert.initData;

public interface BeforeIntiData {
    default void beforeInit() {

    }
}
