package com.example.Trip_In_Jeju.member.initData;

public interface BeforeIntiData {
    default void beforeInit() {

    }
}
