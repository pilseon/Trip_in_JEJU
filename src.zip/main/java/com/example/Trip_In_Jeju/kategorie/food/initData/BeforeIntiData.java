package com.example.Trip_In_Jeju.kategorie.food.initData;

public interface BeforeIntiData {
    default void beforeInit() {

    }
}
